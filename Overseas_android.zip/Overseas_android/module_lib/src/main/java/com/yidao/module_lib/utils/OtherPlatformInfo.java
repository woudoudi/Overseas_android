package com.yidao.module_lib.utils;

/**
 * Created with XIAOYUDEXIEE.
 * Date: 2019/8/16
 */
public class OtherPlatformInfo {

    private OtherPlatformInfo otherPlatformInfo;

    public OtherPlatformInfo getInstance(){
        if (otherPlatformInfo==null) {
            otherPlatformInfo = new OtherPlatformInfo();
        }
        return otherPlatformInfo;
    }

    public void getWeiBoUserInfo(){

    }

}
