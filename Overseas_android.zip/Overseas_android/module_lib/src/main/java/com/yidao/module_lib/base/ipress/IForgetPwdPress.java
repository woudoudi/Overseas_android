package com.yidao.module_lib.base.ipress;

/**
 * Created with XIAOYUDEXIEE.
 * Date: 2019/8/13
 */
public interface IForgetPwdPress {

     void findPsw();

}
