package com.yidao.module_lib.base.iview;

/**
 * Created with XIAOYUDEXIEE.
 * Date: 2019/8/16
 */
public interface OtherPlatformView {

    void qqLoinSuccess(String result);

    void weiboSuccess(String result);

}
