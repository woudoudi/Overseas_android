package com.yidao.module_lib.base.ibase;

/**
 * Created with XIAOYUDEXIEE.
 * Date: 2019/8/5
 */
public interface IBaseEvent {

}
