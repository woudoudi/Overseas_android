package com.yidao.module_lib.base;

/**
 * Created by xiaochan on 2017/6/26.
 */

public class BaseBean {
    public Object carry;
    public String toString() {
        return super.toString();
    }
}
