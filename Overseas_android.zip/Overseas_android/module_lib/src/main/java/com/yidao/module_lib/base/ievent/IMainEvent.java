package com.yidao.module_lib.base.ievent;

/**
 * Created with XIAOYUDEXIEE.
 * Date: 2019/8/5
 */
public interface IMainEvent {

    void showEvent(String data);
}
