package com.yidao.module_lib.base.iview.user;

import com.yidao.module_lib.base.ibase.IBaseView;

/**
 * Created with XIAOYUDEXIEE.
 * Date: 2019/8/7
 */
public interface IPhoneCodeView extends IBaseView {

    String getCodeNum();

}
