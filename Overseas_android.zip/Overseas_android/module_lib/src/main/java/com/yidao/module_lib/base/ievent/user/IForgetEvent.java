package com.yidao.module_lib.base.ievent.user;

/**
 * Created with XIAOYUDEXIEE.
 * Date: 2019/8/13
 */
public interface IForgetEvent {

    void fingPwd();


}
